# import re
# import docx
# from docx import Document
# import PyPDF2
# import spacy
# import matplotlib.pyplot as plt
# from fpdf import FPDF

# # Load NLP model
# nlp = spacy.load("en_core_web_sm")

# # Extract text from PDF
# def extract_text_from_pdf(file_path):
#     text = ""
#     with open(file_path, "rb") as pdf_file:
#         reader = PyPDF2.PdfReader(pdf_file)
#         for page in reader.pages:
#             text += page.extract_text()
#     return text

# # Extract text from DOCX
# def extract_text_from_docx(file_path):
#     doc = docx.Document(file_path)
#     return " ".join([para.text for para in doc.paragraphs])

# # Analyze resume
# def analyze_resume(resume_text, job_description):
#     resume_doc = nlp(resume_text.lower())
#     job_doc = nlp(job_description.lower())

#     resume_keywords = [token.text for token in resume_doc if token.pos_ in ["NOUN", "PROPN"]]
#     job_keywords = [token.text for token in job_doc if token.pos_ in ["NOUN", "PROPN"]]

#     missing_keywords = set(job_keywords) - set(resume_keywords)
#     matched_keywords = set(job_keywords) & set(resume_keywords)

#     score = (len(matched_keywords) / len(job_keywords)) * 100

#     return {
#         "score": round(score, 2),
#         "matched": list(matched_keywords),
#         "missing": list(missing_keywords)
#     }

# # Create visualization
# def create_chart(result):
#     labels = ['Matched', 'Missing']
#     values = [len(result['matched']), len(result['missing'])]

#     plt.bar(labels, values, color=['green', 'red'])
#     plt.title("Resume Keyword Analysis")
#     plt.savefig("resume_chart.png")
#     plt.close()

# # Generate PDF report
# def generate_pdf(result):
#     pdf = FPDF()
#     pdf.add_page()
#     pdf.set_font("Arial", size=12)

#     pdf.cell(200, 10, txt="AI-Powered Resume Analyzer Report", ln=True, align="C")
#     pdf.ln(10)

#     pdf.cell(200, 10, txt=f"Resume Score: {result['score']}%", ln=True)
#     pdf.ln(5)

#     pdf.cell(200, 10, txt="Matched Keywords:", ln=True)
#     pdf.multi_cell(0, 10, ", ".join(result['matched']))
#     pdf.ln(5)

#     pdf.cell(200, 10, txt="Missing Keywords:", ln=True)
#     pdf.multi_cell(0, 10, ", ".join(result['missing']))
#     pdf.ln(10)

#     pdf.image("resume_chart.png", x=50, y=None, w=100)

#     pdf.output("resume_report.pdf")

# # Example usage
# if __name__ == "__main__":
#     resume_text = extract_text_from_pdf("resume.pdf")
#     job_description = """
#     Looking for a Data Scientist with skills in Python, Machine Learning, SQL, and Data Visualization.
#     """

#     result = analyze_resume(resume_text, job_description)
#     create_chart(result)
#     generate_pdf(result)

#     print("Report generated: resume_report.pdf")
import re
import docx
import PyPDF2
import spacy
import matplotlib.pyplot as plt
from fpdf import FPDF
import streamlit as st

# Load NLP model
nlp = spacy.load("en_core_web_sm")

# ------------------- FUNCTIONS -------------------

def extract_text_from_pdf(file):
    reader = PyPDF2.PdfReader(file)
    text = ""
    for page in reader.pages:
        text += page.extract_text()
    return text

def extract_text_from_docx(file):
    doc = docx.Document(file)
    return " ".join([para.text for para in doc.paragraphs])

def analyze_resume(resume_text, job_description):
    resume_doc = nlp(resume_text.lower())
    job_doc = nlp(job_description.lower())

    resume_keywords = [token.text for token in resume_doc if token.pos_ in ["NOUN", "PROPN"]]
    job_keywords = [token.text for token in job_doc if token.pos_ in ["NOUN", "PROPN"]]

    matched = set(job_keywords) & set(resume_keywords)
    missing = set(job_keywords) - set(resume_keywords)

    score = (len(matched) / len(job_keywords)) * 100 if job_keywords else 0

    return {
        "score": round(score, 2),
        "matched": list(matched),
        "missing": list(missing)
    }

def create_chart(result):
    labels = ['Matched', 'Missing']
    values = [len(result['matched']), len(result['missing'])]

    plt.bar(labels, values)
    plt.title("Resume Keyword Analysis")
    plt.savefig("resume_chart.png")
    plt.close()

def generate_pdf(result):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    pdf.cell(200, 10, "AI-Powered Resume Analyzer Report", ln=True, align="C")
    pdf.ln(10)

    pdf.cell(200, 10, f"Resume Score: {result['score']}%", ln=True)
    pdf.ln(5)

    pdf.multi_cell(0, 10, "Matched Keywords:\n" + ", ".join(result['matched']))
    pdf.ln(5)

    pdf.multi_cell(0, 10, "Missing Keywords:\n" + ", ".join(result['missing']))
    pdf.ln(5)

    pdf.image("resume_chart.png", x=50, w=100)
    pdf.output("resume_report.pdf")

# ------------------- STREAMLIT UI -------------------

st.title("AI-Powered Resume Analyzer")

uploaded_file = st.file_uploader("Upload Resume (PDF or DOCX)", type=["pdf", "docx"])
job_desc = st.text_area("Paste Job Description")

if st.button("Analyze Resume"):
    if uploaded_file and job_desc:
        if uploaded_file.name.endswith(".pdf"):
            resume_text = extract_text_from_pdf(uploaded_file)
        else:
            resume_text = extract_text_from_docx(uploaded_file)

        result = analyze_resume(resume_text, job_desc)
        create_chart(result)
        generate_pdf(result)

        st.success(f"Resume Match Score: {result['score']}%")
        st.write("### Matched Keywords")
        st.write(result["matched"])

        st.write("### Missing Keywords")
        st.write(result["missing"])

        with open("resume_report.pdf", "rb") as f:
            st.download_button("Download PDF Report", f, "resume_report.pdf")
    else:
        st.warning("Please upload resume and job description.")
